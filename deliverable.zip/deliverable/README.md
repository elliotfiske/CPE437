# CPE437
We're doing cool fun stuff wow

# TO DO THINGS
`npm install`
`npm start`

And then go to localhost:3000!

## Requirements

In the Clint/ directory:

```
1. An init.sql file giving your create table statements for the
background database.
2. A description of the REST interface.  I'd like something like what we
had in class, though it needn't be as fully written out -- just enough
notes so you know what your interface is doing for each resource/verb
combination, which you'll need anyway to keep from going nuts debugging
things.
3. A description of the views you plan to have
```